#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"
#include "memory.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;
// 内存管理器
MemoryManager memoryManager;

int size=3;
int queue[3]={0};
int left=0,right=0;

bool exist(int a)
{
     for(int i=left;i<left+3-size;i++)
     {
     if(queue[i%3]==a)
     return 1;
     }
     return 0;
}

void push(int a)
{
   queue[right]=a;
   right=(right+1)%3;
   size--;
}

int pop()
{
  int temp=queue[left];
  left=(left+1)%3;
  size++;
  return temp;
}

void swap(int a,int b)
{
  memoryManager.swap(AddressPoolType::KERNEL,a,b);
}

void first_thread(void *arg)
{
    // 第1个线程不可以返回
     stdio.moveCursor(0);
     for (int i = 0; i < 25 * 80; ++i)
     {
         stdio.print(' ');
     }
     stdio.moveCursor(0);

    int pages[20]={7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1};
    for(int i=0;i<20;i++)
    {
       if(!exist(pages[i]))
       {
       if(size!=0)
       {
          char* page=(char *)memoryManager.allocatePages2(AddressPoolType::KERNEL,pages[i]);
	  push(pages[i]);
       }
       else
      {
	 int temp=pop();
	 swap(temp,pages[i]);
	 push(pages[i]);
      }
      }
      else
      printf("hit\n");
    }
    asm_halt();
}


extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 内存管理器
    memoryManager.openPageMechanism();
    memoryManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
