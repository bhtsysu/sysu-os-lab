#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"
#include "memory.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;
// 内存管理器
MemoryManager memoryManager;

int size=3;
int queue[3]={-1,-1,-1};
int count[3]={0};

int exist(int a)
{
     for(int i=0;i<3;i++)
     {
     if(queue[i]==a)
     return i;
     }
     return -1;
}

int max(void)
{
  int ans;
  int temp=0;
  for(int i=0;i<3;i++)
{
	if(count[i]>temp)
	{
		temp=count[i];
		ans=i;
	}
}
return ans;
}

void swap(int a,int b)
{
  memoryManager.swap(AddressPoolType::KERNEL,a,b);
}

void first_thread(void *arg)
{
    // 第1个线程不可以返回
     stdio.moveCursor(0);
     for (int i = 0; i < 25 * 80; ++i)
     {
         stdio.print(' ');
     }
     stdio.moveCursor(0);

    int pages[20]={7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1};
    for(int i=0;i<20;i++)
    {
       if(exist(pages[i])==-1)
       {
       if(size!=0)
       {
          char* page=(char *)memoryManager.allocatePages2(AddressPoolType::KERNEL,pages[i]);
	  queue[3-size]=pages[i];
	  count[3-size]=1;
	  size--;
	  for(int i=0;i<3;i++)
          if(count[i]!=0&&i!=3-size)
          count[i]++;
       }
      else
      {
	 int temp=max();
	 swap(queue[temp],pages[i]);
	 queue[temp]=pages[i];
	 count[temp]=1;
	 for(int i=0;i<3;i++)
          if(count[i]!=0&&i!=temp)
          count[i]++;
      }
      }
      else
      {
      int temp=exist(pages[i]);
      count[temp]=1;
      for(int i=0;i<3;i++)
          if(count[i]!=0&&i!=temp)
          count[i]++;
      printf("hit\n");
      }
    }
    asm_halt();
}


extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 内存管理器
    memoryManager.openPageMechanism();
    memoryManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
