#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;

Semaphore rw,w,mutex;

int readCount;

char *str1=(char*)"This is original quote 1";
char *str2=(char*)"This is original quote 2";
char *str3=(char*)"This is original quote 3";
char *str4=(char*)"This is original quote 4";

void readFirstQuote(void *arg)
{
    rw.P();
    mutex.P();
    readCount++;
    if(readCount==1){w.P();}
    mutex.V();
    rw.V();

    printf("%s\n",str1);
    
    mutex.P();
    readCount--;
    if(readCount==0){w.V();}
    mutex.V();
}

void readSecondQuote(void *arg)
{
    rw.P();
    mutex.P();
    readCount++;
    if(readCount==1){w.P();}
    mutex.V();
    rw.V();

    printf("%s\n",str2);

    mutex.P();
    readCount--;
    if(readCount==0){w.V();}
    mutex.V();

}

void readThirdQuote(void *arg)
{
    rw.P();
    mutex.P();
    readCount++;
    if(readCount==1){w.P();}
    mutex.V();
    rw.V();

    printf("%s\n",str3);

    mutex.P();
    readCount--;
    if(readCount==0){w.V();}
    mutex.V();
}

void readFourthQuote(void *arg)
{
    rw.P();
    mutex.P();
    readCount++;
    if(readCount==1){w.P();}
    mutex.V();
    rw.V();

    printf("%s\n",str4);

    mutex.P();
    readCount--;
    if(readCount==0){w.V();}
    mutex.V();
}

void writeSecondQuote(void *arg)
{
    rw.P();
    w.P();

    int delay=10000000000;
    while(delay)
    delay--;
    str2=(char*)"This is new quote 2"; 
    w.V();
    rw.V();

}

void writeFourthQuote(void *arg)
{
    rw.P();
    w.P();
    int delay=10000000000;
    while(delay)
    delay--;
    str4=(char*)"This is new quote 4";
    w.V();
    rw.V();
}

void zero_thread(void *arg)
{
    // 第0个线程不可以返回
    stdio.moveCursor(0);
    for (int i = 0; i < 25 * 80; ++i)
    {
        stdio.print(' ');
    }
    stdio.moveCursor(0);

    rw.initialize(1);
    w.initialize(1);
    mutex.initialize(1);

     //模拟读错误
    //创建线程读第1-4条记录
    programManager.executeThread(readFirstQuote, nullptr, "first thread", 1);
    programManager.executeThread(readSecondQuote, nullptr, "second thread", 1);
    programManager.executeThread(readThirdQuote, nullptr, "third thread", 1);
    programManager.executeThread(readFourthQuote, nullptr, "fourth thread", 1);
    //创建线程，修改第2条和第4条记录为较长内容
    //由于写时间较长，写线程运行时间大于RRschedule的time quantum
    programManager.executeThread(writeSecondQuote, nullptr, "fifth thread", 1);
    programManager.executeThread(writeFourthQuote, nullptr, "sixth thread", 1);
    //创建线程读第2条和第4条记录
    //发现没有读到修改后的项，而是输出了初始项   
    programManager.executeThread(readSecondQuote, nullptr, "seventh thread", 1);
    programManager.executeThread(readFourthQuote, nullptr, "eighth thread", 1);

    asm_halt();
}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(zero_thread, nullptr, "zero thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
