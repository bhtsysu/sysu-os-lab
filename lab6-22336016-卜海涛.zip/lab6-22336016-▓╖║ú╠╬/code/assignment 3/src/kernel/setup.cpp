#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;

Semaphore chop[5];

void take(int i)
{
    chop[i].P();
    printf("  I take No.%d chopstick\n",i);
}

void put(int i)
{
    chop[i].V();
}

void philosopher(void *arg)
{
    int i=(int)arg;
    printf("philosopher %d:\n",i);
    take(i);
    int delay=10000000000;
    while(delay){delay--;}
    
    take((i+1)%5);
    
    
    printf("  I am eating\n",i);

    put(i);
    put((i+1)%5);
}

void zero_thread(void *arg)
{
    stdio.moveCursor(0);
    for (int i = 0; i < 25 * 80; ++i)
    {
        stdio.print(' ');
    }
    stdio.moveCursor(0);

    for (int i=0;i<5;i++)
    {
        chop[i].initialize(1);
    }
    int i=0;
    programManager.executeThread(philosopher,(void*)i,"first thread",1);
    programManager.executeThread(philosopher,(void*)(i+1),"second thread",1);
    programManager.executeThread(philosopher,(void*)(i+2),"third thread",1);
    programManager.executeThread(philosopher,(void*)(i+3),"fourth thread",1);
    programManager.executeThread(philosopher,(void*)(i+4),"fifth thread",1);

    while(programManager.readyPrograms.size()!=1)
    {
	
    }
    chop[0].V();    
    asm_halt();
}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(zero_thread, nullptr, "zero thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
